package com.notificationassistant.ai.capture

import android.app.Notification
import android.service.notification.StatusBarNotification

/** 三个过滤中的前两个；第三个（内容哈希去重）在 NotificationRepository.saveIfNew 里。 */
object NotificationFilter {

    fun shouldCapture(sbn: StatusBarNotification, selfPackage: String): Boolean {
        // 1. 排除自身
        if (sbn.packageName == selfPackage) return false

        val flags = sbn.notification.flags

        // 2a. 忽略常驻通知（音乐播放器、下载、前台服务等）
        if (sbn.isOngoing || (flags and Notification.FLAG_FOREGROUND_SERVICE) != 0) return false

        // 2b. 忽略群组汇总通知（真正的内容在各条子通知里）
        if ((flags and Notification.FLAG_GROUP_SUMMARY) != 0) return false

        return true
    }
}
