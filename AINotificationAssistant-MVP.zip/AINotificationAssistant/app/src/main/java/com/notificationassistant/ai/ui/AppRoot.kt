package com.notificationassistant.ai.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.notificationassistant.ai.ui.screens.DetailScreen
import com.notificationassistant.ai.ui.screens.HomeScreen
import com.notificationassistant.ai.ui.screens.InsightsScreen
import com.notificationassistant.ai.ui.screens.SettingsScreen
import com.notificationassistant.ai.ui.screens.TimelineScreen

private enum class TopLevel(val route: String, val label: String, val icon: ImageVector) {
    HOME("home", "首页", Icons.Filled.Home),
    TIMELINE("timeline", "时间线", Icons.Filled.DateRange),
    INSIGHTS("insights", "洞察", Icons.Filled.Search),
    SETTINGS("settings", "设置", Icons.Filled.Settings)
}

private const val ROUTE_DETAIL = "detail/{id}"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val currentTop = TopLevel.entries.firstOrNull { it.route == currentRoute }

    Scaffold(
        topBar = {
            if (currentTop != null) {
                CenterAlignedTopAppBar(title = { Text(currentTop.label) })
            } else if (currentRoute == ROUTE_DETAIL) {
                androidx.compose.material3.TopAppBar(
                    title = { Text("通知详情") },
                    navigationIcon = {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (currentTop != null) {
                NavigationBar {
                    TopLevel.entries.forEach { item ->
                        NavigationBarItem(
                            selected = item == currentTop,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(TopLevel.HOME.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = TopLevel.HOME.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(TopLevel.HOME.route) { HomeScreen() }
            composable(TopLevel.TIMELINE.route) {
                TimelineScreen(onOpenDetail = { id -> navController.navigate("detail/$id") })
            }
            composable(TopLevel.INSIGHTS.route) { InsightsScreen() }
            composable(TopLevel.SETTINGS.route) { SettingsScreen() }
            composable(
                route = ROUTE_DETAIL,
                arguments = listOf(navArgument("id") { type = NavType.LongType })
            ) { entry ->
                DetailScreen(id = entry.arguments?.getLong("id") ?: -1L)
            }
        }
    }
}
