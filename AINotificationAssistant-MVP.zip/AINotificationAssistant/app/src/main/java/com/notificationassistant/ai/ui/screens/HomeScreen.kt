package com.notificationassistant.ai.ui.screens

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.notificationassistant.ai.capture.ListenerController
import com.notificationassistant.ai.capture.ListenerState
import com.notificationassistant.ai.permission.PermissionHelper
import com.notificationassistant.ai.ui.AppViewModelProvider
import com.notificationassistant.ai.ui.HomeViewModel

@Composable
fun HomeScreen(viewModel: HomeViewModel = viewModel(factory = AppViewModelProvider.Factory)) {
    val context = LocalContext.current

    val connected by ListenerState.connected.collectAsStateWithLifecycle()
    val total by viewModel.totalCount.collectAsStateWithLifecycle()
    val today by viewModel.todayCount.collectAsStateWithLifecycle()
    val limitedApps by viewModel.limitedApps.collectAsStateWithLifecycle()

    var listenerEnabled by remember { mutableStateOf(PermissionHelper.isListenerEnabled(context)) }
    var postGranted by remember { mutableStateOf(PermissionHelper.isPostNotificationGranted(context)) }

    // 从系统设置页回来时刷新权限状态
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        listenerEnabled = PermissionHelper.isListenerEnabled(context)
        postGranted = PermissionHelper.isPostNotificationGranted(context)
    }

    val postPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> postGranted = granted }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. 通知使用权
        StatusCard(
            title = "通知使用权",
            ok = listenerEnabled,
            status = if (listenerEnabled) "已开启" else "未开启",
            hint = if (listenerEnabled) null else
                "需要开启后才能读取通知。若开关是灰色、点不动（Android 13+ 侧载安装的应用常见）：" +
                    "先点下面“应用信息”，右上角 ⋮ →“允许受限制的设置”，再回来开启。",
            actionLabel = if (listenerEnabled) null else "去开启",
            onAction = { PermissionHelper.openListenerSettings(context) },
            secondaryLabel = if (listenerEnabled) null else "应用信息",
            onSecondary = { PermissionHelper.openAppDetails(context) }
        )

        // 2. 监听服务运行状态
        val serviceOk = listenerEnabled && connected
        StatusCard(
            title = "监听服务",
            ok = serviceOk,
            status = when {
                !listenerEnabled -> "未启用（需先开启通知使用权）"
                connected -> "运行中"
                else -> "未连接"
            },
            hint = if (listenerEnabled && !connected)
                "服务已授权但没有连上系统。点“重新连接”；仍不行请到系统通知使用权页把开关关了再开。" else null,
            actionLabel = if (listenerEnabled && !connected) "重新连接" else null,
            onAction = { ListenerController.forceReconnect(context) }
        )

        // 3. 发通知权限（Android 13+）
        if (PermissionHelper.needsPostNotificationPermission()) {
            StatusCard(
                title = "发送通知权限",
                ok = postGranted,
                status = if (postGranted) "已授权" else "未授权",
                hint = if (postGranted) null else "Android 13+ 需要授权，后续阶段用于推送摘要提醒。",
                actionLabel = if (postGranted) null else "授权",
                onAction = {
                    if (Build.VERSION.SDK_INT >= 33) {
                        postPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            )
        }

        // 4. 入库数量
        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                CountBlock(label = "今日入库", value = today)
                CountBlock(label = "累计入库", value = total)
            }
        }

        // 5. 抓不到完整内容的应用
        if (limitedApps.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("内容不完整的应用", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "这些应用的通知标题或正文为空，后续做摘要时需要特殊处理。",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    limitedApps.forEach { app ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(app.appName, modifier = Modifier.weight(1f), maxLines = 1)
                            Text("${app.total} 条")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusCard(
    title: String,
    ok: Boolean,
    status: String,
    hint: String?,
    actionLabel: String?,
    onAction: () -> Unit,
    secondaryLabel: String? = null,
    onSecondary: () -> Unit = {}
) {
    val container = if (ok) MaterialTheme.colorScheme.secondaryContainer
    else MaterialTheme.colorScheme.errorContainer
    val content = if (ok) MaterialTheme.colorScheme.onSecondaryContainer
    else MaterialTheme.colorScheme.onErrorContainer

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = container, contentColor = content)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(status, fontWeight = FontWeight.Bold)
            }
            if (hint != null) {
                Text(hint, style = MaterialTheme.typography.bodySmall)
            }
            if (actionLabel != null || secondaryLabel != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (actionLabel != null) {
                        Button(onClick = onAction) { Text(actionLabel) }
                    }
                    if (secondaryLabel != null) {
                        OutlinedButton(onClick = onSecondary) { Text(secondaryLabel) }
                    }
                }
            }
        }
    }
}

@Composable
private fun CountBlock(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}
