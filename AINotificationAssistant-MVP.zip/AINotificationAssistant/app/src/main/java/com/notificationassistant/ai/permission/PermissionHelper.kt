package com.notificationassistant.ai.permission

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object PermissionHelper {

    /** 是否已授予“通知使用权”（通知读取权限）。 */
    fun isListenerEnabled(context: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackageNames(context)
            .contains(context.packageName)

    /** Android 13+ 才需要运行时申请发通知权限，更低版本视为已授予。 */
    fun isPostNotificationGranted(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

    fun needsPostNotificationPermission(): Boolean = Build.VERSION.SDK_INT >= 33

    fun openListenerSettings(context: Context) =
        start(context, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    /** 应用信息页：Android 13+ 侧载应用需要在这里“允许受限制的设置”才能开通知使用权。 */
    fun openAppDetails(context: Context) = start(
        context,
        Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", context.packageName, null)
        )
    )

    fun openBatteryOptimizationSettings(context: Context) =
        start(context, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))

    private fun start(context: Context, intent: Intent) {
        try {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(context, "无法打开系统设置页，请手动前往系统设置", Toast.LENGTH_LONG).show()
        }
    }
}
