package com.notificationassistant.ai

import android.content.Context
import com.notificationassistant.ai.data.NotificationRepository
import com.notificationassistant.ai.data.local.AppDatabase

/**
 * 手写的极简依赖容器（MVP 阶段不引入 Hilt，减少注解处理，手机上构建更快）。
 * 后续要换 Hilt 时，只需把这里的两个对象改成 @Provides 即可。
 */
class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    private val database: AppDatabase by lazy { AppDatabase.build(appContext) }

    val notificationRepository: NotificationRepository by lazy {
        NotificationRepository(database.notificationDao())
    }
}
