package com.notificationassistant.ai.capture

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.notificationassistant.ai.NotificationAssistantApp
import com.notificationassistant.ai.data.NotificationRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * 通知监听服务。
 * onNotificationPosted 里只做：过滤 → 解析 → 入库。没有任何网络请求。
 * 日志只记录异常类型，绝不记录通知标题/正文。
 */
class NotificationCaptureService : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var parser: NotificationParser
    private lateinit var repository: NotificationRepository

    override fun onCreate() {
        super.onCreate()
        parser = NotificationParser(applicationContext)
        repository = (application as NotificationAssistantApp).container.notificationRepository
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        ListenerState.setConnected(true)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        ListenerState.setConnected(false)
        // 与系统断开后主动请求重新绑定
        ListenerController.requestRebind(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            if (!NotificationFilter.shouldCapture(sbn, packageName)) return
            val entity = parser.parse(sbn)
            scope.launch {
                try {
                    repository.saveIfNew(entity)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "save failed: ${e.javaClass.simpleName}")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "parse failed: ${e.javaClass.simpleName}")
        }
    }

    override fun onDestroy() {
        ListenerState.setConnected(false)
        scope.cancel()
        super.onDestroy()
    }

    private companion object {
        const val TAG = "NotificationCapture"
    }
}
