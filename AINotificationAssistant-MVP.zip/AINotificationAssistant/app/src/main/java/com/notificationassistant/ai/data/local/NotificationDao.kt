package com.notificationassistant.ai.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(entity: NotificationEntity): Long

    /** 去重：同一内容哈希在 since 之后是否已有记录 */
    @Query("SELECT COUNT(*) FROM notifications WHERE contentHash = :hash AND postedAt >= :since")
    suspend fun countByHashSince(hash: String, since: Long): Int

    @Query("SELECT * FROM notifications ORDER BY postedAt DESC, id DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<NotificationEntity>>

    @Query("SELECT * FROM notifications WHERE id = :id")
    fun observeById(id: Long): Flow<NotificationEntity?>

    @Query("SELECT COUNT(*) FROM notifications")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM notifications WHERE postedAt >= :since")
    fun observeCountSince(since: Long): Flow<Int>

    @Query(
        "SELECT packageName, appName, COUNT(*) AS total FROM notifications " +
            "WHERE contentAvailability != 'FULL' " +
            "GROUP BY packageName ORDER BY total DESC LIMIT 20"
    )
    fun observeLimitedApps(): Flow<List<LimitedAppStat>>

    @Query("DELETE FROM notifications")
    suspend fun clearAll()
}
