package com.notificationassistant.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.notificationassistant.ai.data.local.ContentAvailability
import com.notificationassistant.ai.data.local.NotificationEntity
import com.notificationassistant.ai.ui.AppViewModelProvider
import com.notificationassistant.ai.ui.DetailViewModel
import com.notificationassistant.ai.ui.util.formatFull

@Composable
fun DetailScreen(id: Long) {
    val viewModel: DetailViewModel = viewModel(
        key = "detail-$id",
        factory = AppViewModelProvider.detailFactory(id)
    )
    val item by viewModel.notification.collectAsStateWithLifecycle()

    val current = item
    if (current == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("未找到这条通知（可能已被清空）", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        DetailContent(current)
    }
}

@Composable
private fun DetailContent(item: NotificationEntity) {
    val availability = ContentAvailability.fromName(item.contentAvailability)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SelectionContainer {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    item.title.ifEmpty { "（无标题）" },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    item.text.ifEmpty { "（无正文）" },
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }

        HorizontalDivider()

        MetaRow("应用", item.appName)
        MetaRow("包名", item.packageName)
        MetaRow("通知时间", formatFull(item.postedAt))
        MetaRow("入库时间", formatFull(item.createdAt))
        MetaRow("内容完整度", availability.label)
        MetaRow("常驻通知", if (item.isOngoing) "是" else "否")
        MetaRow("群组汇总", if (item.isGroupSummary) "是" else "否")
        MetaRow("通知 Key", item.notificationKey)
        MetaRow("内容哈希", item.contentHash.take(16) + "…")
    }
}

@Composable
private fun MetaRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        SelectionContainer {
            Text(value.ifEmpty { "-" }, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
