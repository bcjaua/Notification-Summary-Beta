package com.notificationassistant.ai.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * 通知内容的可获取程度。后续做摘要时，用它判断哪些通知没有可用内容。
 * 数据库里存 name（字符串），避免引入 TypeConverter。
 */
enum class ContentAvailability(val label: String) {
    FULL("完整"),
    TITLE_ONLY("仅标题"),
    TEXT_ONLY("仅正文"),
    EMPTY("无内容");

    companion object {
        fun fromName(name: String): ContentAvailability =
            entries.firstOrNull { it.name == name } ?: EMPTY
    }
}

@Entity(
    tableName = "notifications",
    indices = [
        Index(value = ["contentHash", "postedAt"]),
        Index(value = ["postedAt"])
    ]
)
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appName: String,
    val title: String,
    val text: String,
    /** 通知发布时间（StatusBarNotification.postTime） */
    val postedAt: Long,
    val notificationKey: String,
    val isOngoing: Boolean,
    val isGroupSummary: Boolean,
    /** SHA-256(packageName + title + text)，用于去重 */
    val contentHash: String,
    /** ContentAvailability.name */
    val contentAvailability: String,
    /** 入库时间 */
    val createdAt: Long
)

/** “抓不到完整内容的应用”统计 */
data class LimitedAppStat(
    val packageName: String,
    val appName: String,
    val total: Int
)
