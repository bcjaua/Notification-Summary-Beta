package com.notificationassistant.ai.data

import com.notificationassistant.ai.data.local.LimitedAppStat
import com.notificationassistant.ai.data.local.NotificationDao
import com.notificationassistant.ai.data.local.NotificationEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class NotificationRepository(private val dao: NotificationDao) {

    private val saveMutex = Mutex()

    /**
     * 按内容哈希去重后入库。返回 true 表示真的写入了一条新记录。
     *
     * 去重规则：同一个 contentHash，如果在 [DEDUP_WINDOW_MS] 窗口内已经有记录就跳过。
     * - 监听服务每次（重新）连接时，系统会把当前仍在通知栏的通知再投递一遍，
     *   它们的 postTime 与旧记录相同，会被这条规则挡住。
     * - 应用对同一通知的反复刷新（进度、同步等）同样会被挡住。
     * - 隔了很久之后再次出现的相同内容（比如不同日期的“好的”）仍会正常入库。
     * 想要“永久只存一条”，把窗口改成 Long.MAX_VALUE 即可。
     */
    suspend fun saveIfNew(entity: NotificationEntity): Boolean = saveMutex.withLock {
        val since = entity.postedAt - DEDUP_WINDOW_MS
        if (dao.countByHashSince(entity.contentHash, since) > 0) {
            false
        } else {
            dao.insert(entity) > 0
        }
    }

    fun observeRecent(limit: Int = 500): Flow<List<NotificationEntity>> = dao.observeRecent(limit)

    fun observeById(id: Long): Flow<NotificationEntity?> = dao.observeById(id)

    fun observeTotalCount(): Flow<Int> = dao.observeTotalCount()

    fun observeCountSince(since: Long): Flow<Int> = dao.observeCountSince(since)

    fun observeLimitedApps(): Flow<List<LimitedAppStat>> = dao.observeLimitedApps()

    suspend fun clearAll() = dao.clearAll()

    companion object {
        const val DEDUP_WINDOW_MS: Long = 10 * 60 * 1000L
    }
}
