package com.notificationassistant.ai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.notificationassistant.ai.NotificationAssistantApp
import com.notificationassistant.ai.data.NotificationRepository
import com.notificationassistant.ai.data.local.LimitedAppStat
import com.notificationassistant.ai.data.local.NotificationEntity
import com.notificationassistant.ai.ui.util.startOfTodayMillis
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val STOP_TIMEOUT_MS = 5_000L

class HomeViewModel(repository: NotificationRepository) : ViewModel() {

    val totalCount: StateFlow<Int> = repository.observeTotalCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), 0)

    /** 每分钟重新计算“今天 0 点”，跨天后自动归零。 */
    @OptIn(ExperimentalCoroutinesApi::class)
    val todayCount: StateFlow<Int> = flow {
        while (true) {
            emit(startOfTodayMillis())
            delay(60_000)
        }
    }
        .distinctUntilChanged()
        .flatMapLatest { repository.observeCountSince(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), 0)

    val limitedApps: StateFlow<List<LimitedAppStat>> = repository.observeLimitedApps()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())
}

class TimelineViewModel(repository: NotificationRepository) : ViewModel() {

    val notifications: StateFlow<List<NotificationEntity>> = repository.observeRecent()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())
}

class DetailViewModel(id: Long, repository: NotificationRepository) : ViewModel() {

    /** null 表示还在加载或记录不存在，用 loaded 区分太重，MVP 里统一显示“未找到”前先给个短暂空白即可。 */
    val notification: StateFlow<NotificationEntity?> = repository.observeById(id)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)
}

class SettingsViewModel(private val repository: NotificationRepository) : ViewModel() {

    fun clearAll() {
        viewModelScope.launch { repository.clearAll() }
    }
}

object AppViewModelProvider {

    val Factory: ViewModelProvider.Factory = viewModelFactory {
        initializer { HomeViewModel(app().container.notificationRepository) }
        initializer { TimelineViewModel(app().container.notificationRepository) }
        initializer { SettingsViewModel(app().container.notificationRepository) }
    }

    fun detailFactory(id: Long): ViewModelProvider.Factory = viewModelFactory {
        initializer { DetailViewModel(id, app().container.notificationRepository) }
    }
}

private fun CreationExtras.app(): NotificationAssistantApp =
    this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as NotificationAssistantApp
