package com.notificationassistant.ai.capture

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** 监听服务当前是否与系统连接（进程内状态，进程被杀后会回到 false，直到系统重新绑定）。 */
object ListenerState {
    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    fun setConnected(value: Boolean) {
        _connected.value = value
    }
}

object ListenerController {

    private const val TAG = "ListenerController"

    private fun component(context: Context) =
        ComponentName(context, NotificationCaptureService::class.java)

    /** 请求系统重新绑定监听服务。 */
    fun requestRebind(context: Context) {
        try {
            NotificationListenerService.requestRebind(component(context))
        } catch (e: Exception) {
            Log.w(TAG, "requestRebind failed: ${e.javaClass.simpleName}")
        }
    }

    /**
     * 手动“重新连接”：先 requestRebind；再把组件禁用/启用一次，
     * 这是让卡死的监听服务重新被系统绑定的常用办法。
     */
    fun forceReconnect(context: Context) {
        requestRebind(context)
        try {
            val pm = context.packageManager
            val cn = component(context)
            pm.setComponentEnabledSetting(
                cn, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
            )
            pm.setComponentEnabledSetting(
                cn, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP
            )
        } catch (e: Exception) {
            Log.w(TAG, "toggle component failed: ${e.javaClass.simpleName}")
        }
    }
}
