package com.notificationassistant.ai.capture

import android.app.Notification
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.service.notification.StatusBarNotification
import com.notificationassistant.ai.data.local.ContentAvailability
import com.notificationassistant.ai.data.local.NotificationEntity
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * 把 StatusBarNotification 解析成 NotificationEntity。
 * 只做本地解析，不联网；也绝不把标题/正文写进日志。
 */
class NotificationParser(context: Context) {

    private val packageManager: PackageManager = context.applicationContext.packageManager
    private val appNameCache = ConcurrentHashMap<String, String>()

    fun parse(sbn: StatusBarNotification): NotificationEntity {
        val notification = sbn.notification
        val extras = notification.extras

        val title = firstNonBlank(
            extras?.getCharSequence(Notification.EXTRA_TITLE),
            extras?.getCharSequence(Notification.EXTRA_TITLE_BIG)
        )

        val linesText = extras?.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.joinToString("\n") { it?.toString().orEmpty() }

        val text = firstNonBlank(
            extras?.getCharSequence(Notification.EXTRA_BIG_TEXT),
            extras?.getCharSequence(Notification.EXTRA_TEXT),
            linesText,
            lastMessagingText(extras),
            notification.tickerText
        ).take(MAX_TEXT_LENGTH)

        val availability = when {
            title.isNotEmpty() && text.isNotEmpty() -> ContentAvailability.FULL
            title.isNotEmpty() -> ContentAvailability.TITLE_ONLY
            text.isNotEmpty() -> ContentAvailability.TEXT_ONLY
            else -> ContentAvailability.EMPTY
        }

        val now = System.currentTimeMillis()
        return NotificationEntity(
            packageName = sbn.packageName,
            appName = resolveAppName(sbn.packageName),
            title = title,
            text = text,
            postedAt = sbn.postTime,
            notificationKey = sbn.key.orEmpty(),
            isOngoing = sbn.isOngoing,
            isGroupSummary = (notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0,
            contentHash = sha256("${sbn.packageName}\u0000$title\u0000$text"),
            contentAvailability = availability.name,
            createdAt = now
        )
    }

    private fun firstNonBlank(vararg candidates: CharSequence?): String {
        for (c in candidates) {
            val s = c?.toString()?.trim()
            if (!s.isNullOrEmpty()) return s
        }
        return ""
    }

    /** MessagingStyle 通知：取最新一条消息的文字。 */
    @Suppress("DEPRECATION")
    private fun lastMessagingText(extras: android.os.Bundle?): String? {
        return try {
            val parcelables = extras?.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return null
            val messages = Notification.MessagingStyle.Message.getMessagesFromBundleArray(parcelables)
            messages.lastOrNull()?.text?.toString()
        } catch (e: Exception) {
            null
        }
    }

    private fun resolveAppName(pkg: String): String =
        appNameCache.getOrPut(pkg) {
            try {
                val info = if (Build.VERSION.SDK_INT >= 33) {
                    packageManager.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    packageManager.getApplicationInfo(pkg, 0)
                }
                packageManager.getApplicationLabel(info).toString().ifBlank { pkg }
            } catch (e: Exception) {
                pkg
            }
        }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val MAX_TEXT_LENGTH = 4000
    }
}
