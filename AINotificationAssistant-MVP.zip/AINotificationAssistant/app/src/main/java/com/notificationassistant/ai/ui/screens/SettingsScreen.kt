package com.notificationassistant.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.notificationassistant.ai.permission.PermissionHelper
import com.notificationassistant.ai.ui.AppViewModelProvider
import com.notificationassistant.ai.ui.SettingsViewModel

@Composable
fun SettingsScreen(viewModel: SettingsViewModel = viewModel(factory = AppViewModelProvider.Factory)) {
    val context = LocalContext.current
    var showClearDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("权限与稳定性", style = MaterialTheme.typography.titleMedium)

        OutlinedButton(
            onClick = { PermissionHelper.openListenerSettings(context) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("打开通知使用权设置") }

        OutlinedButton(
            onClick = { PermissionHelper.openAppDetails(context) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("打开应用信息（允许受限制的设置）") }

        OutlinedButton(
            onClick = { PermissionHelper.openBatteryOptimizationSettings(context) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("电池优化设置（把本应用设为“不受限制”）") }

        Text("数据", style = MaterialTheme.typography.titleMedium)

        Button(
            onClick = { showClearDialog = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("清空本地通知数据") }

        Text(
            "第一阶段 MVP：通知只保存在本机数据库，不联网、不上传。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("清空本地通知数据？") },
            text = { Text("会删除已入库的全部通知记录，无法恢复。") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clearAll()
                    showClearDialog = false
                }) { Text("清空") }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) { Text("取消") }
            }
        )
    }
}
