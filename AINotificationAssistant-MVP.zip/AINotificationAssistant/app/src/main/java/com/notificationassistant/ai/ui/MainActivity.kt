package com.notificationassistant.ai.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.notificationassistant.ai.capture.ListenerController
import com.notificationassistant.ai.capture.ListenerState
import com.notificationassistant.ai.permission.PermissionHelper
import com.notificationassistant.ai.ui.theme.AppTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                AppRoot()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // 已授权但服务没连上（比如进程被杀后重启）：请求系统重新绑定
        if (PermissionHelper.isListenerEnabled(this) && !ListenerState.connected.value) {
            ListenerController.requestRebind(this)
        }
    }
}
