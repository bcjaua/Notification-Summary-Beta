package com.notificationassistant.ai.ui.util

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val shortFormatter = DateTimeFormatter.ofPattern("MM-dd HH:mm")
private val fullFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

fun formatShort(millis: Long): String = format(millis, shortFormatter)

fun formatFull(millis: Long): String = format(millis, fullFormatter)

private fun format(millis: Long, formatter: DateTimeFormatter): String =
    Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).format(formatter)

fun startOfTodayMillis(): Long =
    LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
